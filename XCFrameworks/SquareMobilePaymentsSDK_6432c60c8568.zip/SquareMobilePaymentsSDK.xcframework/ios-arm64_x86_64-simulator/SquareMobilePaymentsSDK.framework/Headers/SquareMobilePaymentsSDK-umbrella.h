#ifdef __OBJC__
#    import <Foundation/Foundation.h>
#    if __has_include(<UIKit/UIKit.h>)
#        import <UIKit/UIKit.h>
#    endif
#else
#    ifndef FOUNDATION_EXPORT
#        if defined(__cplusplus)
#            define FOUNDATION_EXPORT extern "C"
#        else
#            define FOUNDATION_EXPORT extern
#        endif
#    endif
#endif


FOUNDATION_EXPORT double SquareMobilePaymentsSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char SquareMobilePaymentsSDKVersionString[];
