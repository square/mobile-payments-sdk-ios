//
//  DEAccessibilitySelectionScreen.h
//  SquareReader
//
//

#import "DEDigitEntryScreen.h"
#import "DEDigitEntryCoordinatorSubview.h"
@protocol DEDigitEntryCoordinatorSubview;


@interface DEAccessibilitySelectionScreen : UIView <DEDigitEntryCoordinatorSubview>
@end
