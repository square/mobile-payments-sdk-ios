//
//  CRUserInteractionFeature_Internal.h
//  cardreader
//
//  Created by Martin Mroz on 11/16/15.
//  Copyright © 2015 Square, Inc. All rights reserved.
//

#import "CRUserInteractionFeature.h"


@interface CRUserInteractionFeature ()

@property (nonatomic, assign) struct cr_user_interaction_t *user_interaction;

@end
