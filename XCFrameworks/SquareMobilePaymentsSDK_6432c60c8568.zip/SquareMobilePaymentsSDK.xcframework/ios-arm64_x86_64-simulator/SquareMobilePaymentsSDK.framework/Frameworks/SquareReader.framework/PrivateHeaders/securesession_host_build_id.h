// Copyright 2017 Square, Inc.

/* If this is a PaySDK unique build then we extern this
 * variable and fill it in with buildid_shared library */
extern uint32_t SECURESESSION_HOST_BUILD_ID;
