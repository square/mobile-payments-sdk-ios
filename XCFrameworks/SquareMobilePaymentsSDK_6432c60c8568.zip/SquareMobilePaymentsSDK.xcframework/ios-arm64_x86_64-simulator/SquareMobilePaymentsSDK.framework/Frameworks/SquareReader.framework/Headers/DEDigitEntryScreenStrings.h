//
//  DEDigitEntryScreenStrings.h
//  SquareReader
//
//


@protocol DEDigitEntryScreenStrings
@end
